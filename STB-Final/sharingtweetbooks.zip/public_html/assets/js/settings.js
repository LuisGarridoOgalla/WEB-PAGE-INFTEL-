"use strict";


/*******************************************************************************

System settings

*******************************************************************************/

// System configuration settings
var CONFIG = {
//Twitter
  BEARER_TOKEN:     "AAAAAAAAAAAAAAAAAAAAANW0xgAAAAAAo4D394ufsc8pSu9hZnnl1ZIlwvg%3DlEdGmg44WERzAjdrjYmhLMKoWPTGqCjY8DRNBZTpcmOwvXrbBV",
  NUM_HASHTAGS:     5
};



// System limitations
var LIMITS = {
  MAX_TWEETS:       10 // TODO add the maximum number of tweets we can get.
  //MAX_HASHTAGS:   50  // As imposed by Twitter.
  //NUM_EBAY_ITEMS: 3,
};
